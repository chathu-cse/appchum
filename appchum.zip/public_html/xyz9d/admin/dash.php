<?php

ini_set( 'session.cookie_httponly', 1 );
session_start();

if(!isset($_SESSION["admin"])){
    header("Location : login.php");
}

?>

<html>
    <head>
        <title>Dashboard</title>
    </head>
    <body>
        <h1>New post <a href="newpost.php">Gooo</a></h1>
    </body>
</html>