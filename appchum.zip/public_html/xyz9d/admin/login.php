<?php

ini_set( 'session.cookie_httponly', 1 );                                                               
session_start();

if(isset($_SESSION["admin"])){
    header("Location : dash.php");
}

if(isset($_POST["user"]) && isset($_POST["pass"])){
    if ($_POST["user"] == "dumindu32" && $_POST["pass"] == "3212632126"){
        $_SESSION["admin"] = "pd";
        header("Location:dash.php");
    }else{
        die("You failed. Blocked");
    }
}
?>

<html>
    <head>
        <title>Test</title>
    </head>
    <body>
        <form action="" method="POST">
            USERNAME : <input type="text" name="user" /> <br />
            PASSWORD : <input type="password" name="pass" /> <br />
            <input type="submit" name="submit" />
        </form>
    </body>
</html>

