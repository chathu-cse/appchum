<?php

ini_set( 'session.cookie_httponly', 1 );
session_start();

if(isset($_SESSION["admin"])){                                                                     
    if(isset($_POST["title"]) && isset($_POST["short"])&& isset($_POST["by"]) && isset($_POST["content"])){
        if($_POST["code"] != "32126"){
            die("go away");
        }
        
        
        include("../../engine/dbs/mysql.php");
        include("../../engine/dbs/mysql_funs.php");
        
        $st["title"] = valid($_POST["title"]);
        $st["short"] = valid($_POST["short"]);
        $st["content"] = valid($_POST["content"]);
        $st["date"] = date("Y-m-d");
        $st["by"] = valid($_POST["by"]);
        $st["hash"] = rand(1000,100000);
        
        $query = insert_table("posts",$st);
        if(mysqli_query($conn,$query)){
            die("succedd");
        }else{
            echo mysqli_error($conn);
            echo "Somethin went wrong";
        }
        
    }
}else{
    die("error not log in");
}

?>
<html>
    <head>
        <title>Post a post</title>
    </head>
    <body>
        <h1><a href="dash.php" >Dash</a></h1>
        <h2>Post something</h2>
        <form action="" method="POST">
            TITLE : <input type="text" name="title" /> <br /> <br />
            SHORT : <input type="text" name="short" /> <br /> <br />
            BY : <input type="text" name="by" /> <br /> <br />
            CONTENT : <br />
            <textarea cols="50" rows="50" name="content">
                
            </textarea>  <br /><br />
            CODE : <input type="text" name="code" /> <br /> <br />
            <input type="submit" name="submit" />
        </form>
    </body>
</html>