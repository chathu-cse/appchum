
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "login.xml";
switch($obj["for"]){
    
case "3243":
    $_a = get_item($database,$obj["textbox.txt1.Text"] . $obj["textbox.txt2.Text"]);$obj["textbox.txt3.Visible"] = "none";$obj["textbox.txt4.Visible"] = "none";$obj["textbox.txt5.Visible"] = "none";$obj["textbox.txt6.Visible"] = "none";$obj["textbox.btn2.Visible"] = "none";$obj["imagebox.img.Visible"] = "initial";if($_a == ""){  $obj["imagebox.img.Text"] = "Invalid login data";}else{  $obj["imagebox.img.Text"] = $_a;}
    break;

case "4432":
    $_l = "Your name ->".$obj["textbox.txt5.Text"];$_m = "|Your age ->".$obj["textbox.txt6.Text"];set_item($database,$obj["textbox.txt3.Text"] . $obj["textbox.txt4.Text"], $_l . $_m);$obj["textbox.txt3.Visible"] = "none";$obj["textbox.txt4.Visible"] = "none";$obj["textbox.txt5.Visible"] = "none";$obj["textbox.txt6.Visible"] = "none";$obj["textbox.btn2.Visible"] = "none";$obj["imagebox.img.Visible"] = "initial";$obj["imagebox.img.Text"] = "Succefully created! | ";$obj["imagebox.img.Text"] .= $_l.$_m;;
    break;

    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
