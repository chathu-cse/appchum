
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "concept.xml";
switch($obj["for"]){
    
case "4433":
    $_a = $obj["textbox.txt1.Text"];$_b = $obj["textbox.txt2.Text"];$_res = intval($_a) + intval($_b);$obj["imagebox.img2.Text"] = "Result is ". $_res . ". Calculated by server";
    break;

    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
