
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "feedback.xml";
switch($obj["for"]){
    
case "4790":
    set_item($database,$obj["textbox.txt1.Text"],$obj["textbox.txt2.Text"]);$obj["imagebox.img1.Text"] = "Thank you very much. ♥";$obj["textbox.txt1.Visible"] = "none";$obj["textbox.txt2.Visible"] = "none";$obj["textbox.btn.Visible"] = "none";
    break;

    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
