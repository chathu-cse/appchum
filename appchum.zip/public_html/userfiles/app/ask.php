
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "ask.xml";
switch($obj["for"]){
    
case "4663":
    set_item($database,$obj["textbox.txt1.Text"],$obj["textbox.txt2.Text"]);$obj["imagebox.img1.FontSize"] = "20px";$obj["imagebox.img1.Text"] = "Thank you very much. Answer will be recieved to the email. 😎";$obj["textbox.txt1.Visible"] = "none";$obj["textbox.txt2.Visible"] = "none";$obj["textbox.btn.Visible"] = "none";
    break;

    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
