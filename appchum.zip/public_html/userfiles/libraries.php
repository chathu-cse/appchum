<?php

function char_at($str,$ind){
    $arr = str_split($str);
    return $arr[$ind];
}

function str_contains($ori,$str){
    if(strpos($ori,$str) === false){
        return false;
    }else{
        return true;
    }
}
function starts_with($str,$sear){
    $num = strlen($sear);
    $ext = substr($str,0,$num);
    
    if($sear == $ext){
        return true;
    }else{
        return false;
    }
}

function ends_with($str,$sear){
    $num = strlen($sear) * -1;
    $ext = substr($str,$num);
    
    if($sear == $ext){
        return true;
    }else{
        return false;
    }
}

function str_concat($str1,$str2){
    return $str1.$str2;
}

//dbs
function get_key($file,$key){
    $xml = simplexml_load_file($file);
    $list = $xml->row;

    if(isset($list[$key])){
        return $list[$key]->key;
    }else{
        return "";
    }
}

function get_item($file,$keyname){
    $xml = simplexml_load_file($file);
    $list = $xml->row;
    
    foreach($list as $val){
        if($val->key == $keyname){
            return (string) $val->value;
        }
    }
    
    return "";
}

function get_length($file){
    $xml = simplexml_load_file($file);
    $list = $xml->row;
    

    return count($list);
}

function set_item($file,$keyname,$val=""){
    $xml = simplexml_load_file($file);
    $list = $xml->row;

    $doc = new DOMDocument();
    
    $root = $doc->createElement("database");                            
    
    foreach($list as $key){
        if($key->key != $keyname ){
            $row = $doc->createElement("row");
            $k = $doc->createElement("key",$key->key);
            $v = $doc->createElement("value",$key->value);
            
            $row->appendChild($k);
            $row->appendChild($v);
            $root->appendChild($row);
        }
    }
    
    $row = $doc->createElement("row");
    $k = $doc->createElement("key",$keyname);
    $v = $doc->createElement("value",$val);
    
    $row->appendChild($k);
    $row->appendChild($v);
    $root->appendChild($row);
    
    $doc->appendChild($root);
    $doc->save($file);
}

function remove_item($file,$keyname){
    $xml = simplexml_load_file($file);
    $list = $xml->row;

    $doc = new DOMDocument();
    
    $root = $doc->createElement("database");                            
    
    foreach($list as $key){
        if($key->key != $keyname){
            $row = $doc->createElement("row");
            $k = $doc->createElement("key",$key->key);
            $v = $doc->createElement("value",$key->value);
            
            $row->appendChild($k);
            $row->appendChild($v);
            $root->appendChild($row);
        }
    }
    
    $doc->appendChild($root);
    $doc->save($file);
}

function db_clear($file){
    $doc = new DOMDocument();
    
    $root = $doc->createElement("database");
    $doc->appendChild($root);
    $doc->save($file);
}
?>