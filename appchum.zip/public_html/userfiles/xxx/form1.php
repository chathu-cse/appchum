
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "form1.xml";
switch($obj["for"]){
    
    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
