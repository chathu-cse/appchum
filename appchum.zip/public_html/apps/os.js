function send_data(obj,url){var text=encodeURIComponent(JSON.stringify(obj));var xhr=new XMLHttpRequest();xhr.onreadystatechange=function(){if(xhr.readyState==4&&xhr.status==200){reciever(xhr.responseText)}}
xhr.open("POST",url,!0);xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");xhr.send("d="+text)}
class CheckBox{constructor(elm){this.div=elm;this.in=elm.querySelector("input");this.lbl=elm.querySelector("label")}}
class Database{constructor(name){this.app=name}
length(){var json_str=localStorage.getItem(this.app);if(json_str!=null){var obj=JSON.parse(json_str);return Object.keys(obj).length}else{return 0}
return 0}
key(ind){var json_str=localStorage.getItem(this.app);if(json_str!=null){var obj=JSON.parse(json_str);var arr=Object.keys(obj);return arr[ind]}
return""}
getItem(inp){var json_str=localStorage.getItem(this.app);if(json_str!=null){var obj=JSON.parse(json_str);return obj[inp]}
return""}
setItem(key,val){var json_str=localStorage.getItem(this.app);var obj;if(json_str!=null){obj=JSON.parse(json_str);obj[key]=val}else{obj={};obj[key]=val}
var new_json=JSON.stringify(obj);localStorage.setItem(this.app,new_json)}
removeItem(keyin){var json_str=localStorage.getItem(this.app);var obj={};if(json_str!=null){obj=JSON.parse(json_str);delete obj[keyin]}
var new_json=JSON.stringify(obj);localStorage.setItem(this.app,new_json)}
clear(){var obj={};var new_json=JSON.stringify(obj);localStorage.setItem(this.app,new_json)}}
class Mail{constructor(){this.from="";this.to="";this.subject="";this.body=""}
send(){var obj={from:this.from,to:this.to,subject:this.subject,body:this.body}
var txt=JSON.stringify(obj);txt=encodeURIComponent(txt);var xhr=new XMLHttpRequest();xhr.open("POST","lib/mail",!0);xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");xhr.send("d="+txt)}}
var $Form={div:document.getElementById("form"),doc:document}