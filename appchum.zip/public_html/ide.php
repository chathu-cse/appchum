<?php
if(!isset($_COOKIE["token"])){
    header("Location:/");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Appchum IDE</title>
        <meta name="description" content="The IDE to use to develop web apps">
        <meta name="author" content="Dumindu Chathuranga">
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <link rel="stylesheet" href="css/ide.css" />
        <link rel="stylesheet" href="css/codemirror.css" />
        <link rel="icon" type="image/ico" href="https://appchum.com/images/favicon.ico">
    </head>
    <body>
        <div id="wrapper">
            <div id="menu">
                <div id="command-box">
                    <button class="button font" id="addform">+ Form</button>
                    
                    <button class="button font right" id="publishform" >Publish</button>
                </div>
                <div id="tools-box">
                    <div class="tool">
                        <div class="tool-name">Button</div>
                        <div class="tool-con">
                            <button tool="button" draggable="true">drag me</button>
                        </div>
                    </div>
                    <div class="tool">
                        <div class="tool-name">TextBox</div>
                        <div class="tool-con">
                            <input type="text" value="drag me" tool="textbox" draggable="true"/>
                        </div>
                    </div>
                    <div class="tool">
                        <div class="tool-name">CheckBox</div>
                        <div class="tool-con">
                            <div style="background-color:#fff;" draggable="true" tool="checkbox">
                                <input type="checkbox"/>drag me
                            </div>
                        </div>
                    </div>
                    <div class="tool">
                        <div class="tool-name">Password</div>
                        <div class="tool-con">
                            <input type="password" placeholder="drag me" tool="password" draggable="true"/>
                        </div>
                    </div>
                    <div class="tool">
                        <div class="tool-name">ImageBox/Label</div>
                        <div class="tool-con">
                            <div class="image-tool" draggable="true" width="100" height="150" tool="imagebox">drag me</div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="env">
                <div id="design">
                    <div id="design-tabs">
                        <button>Intro</button>
                    </div>
                    <div id="indi-tabs">
                    </div>
                    <div id="design-area">
                        <div class="indi-area">
                            <div class="gui editor">
                                <h1>Wellcome</h1>
                                <h4>Click "+ Form" button to add a form</h4>
                                <h4>You can create 3 forms per app.</h4>
                                <h4>There is no save option. If you close this tab you will loose the progress. But 
                                you can overide the forms by visiting appchum.com/ide again.</h4>
                                <h4>Be careful when deciding form name. You can't changed it after "publish"</h4>
                                <h4>You will get a appchum.com/apps/appname/formname like url for each form.</h4>
                                <h4>Databases will be created automaticaly if you use Database in your code. Databases will get
                                 a appchum.com/databases/appname/formname like url.</h4>
                                 <h4>Language is case sensitive !</h4>
                                 <h4>Language reference</h4>
                                 <h5>
                                     <a target="_blank" href="lang/statements.html">If statement</a>
                                     <a target="_blank" href="lang/statements.html">For loop</a>
                                     <a target="_blank" href="lang/statements.html">While loop</a> <br />
                                     <a target="_blank" href="lang/statements.html">Statements</a>
                                     <a target="_blank" href="lang/string.html">Strings</a>
                                     <a target="_blank" href="lang/math.html">Math</a>
                                     <a target="_blank" href="lang/database.html">Databases</a>
                                     <a target="_blank" href="lang/events.html">Events</a> <br />
                                     
                                     <a target="_blank" href="lang/form.html">Form</a>
                                     <a target="_blank" href="lang/control.html">Textbox</a>
                                     <a target="_blank" href="lang/control.html">Button</a>
                                     <a target="_blank" href="lang/control.html">Password</a>
                                     <a target="_blank" href="lang/imagebox.html">Imagebox / Label</a>
                                     <a target="_blank" href="lang/checkbox.html">Checkbox</a>

                                 </h5>
                                 <h4>Your questions - dumindu.cse@yahoo.com</h4>
                                 <h3>Happy developing :)</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="prop-area">
                    <div class="tool-prop">
                        <div class="prop-type"></div>
                    </div>
                </div>
                <div style="overflow:scroll;height:300px;" id="console">
                    <div class="prop-type">Console</div>
                </div>
            </div>
        </div>
        <!-- aii -->
        <div id="aistuf">
            <div style="display:none;" id="tip-var">
                <b>Declaring a variable</b><br />
                Syntax <br />
                <pre><code>Dim identifier As datatype = value</code></pre>
                <div>At the moment Appchum supports only 3 data types -> String, Integer, Boolean (Integer includes float values.) <br />Ex:</div>
                <pre><code>Dim str As String = "hi, chum"
Dim num As Integer = 4.5</code></pre>
            </div>
            <div id="tip-ref">
                <b>Quick reference</b> <br />
                <a href="#tip-ref" onclick="analize('Dim');">Variables</a>
                <a href="#tip-ref" onclick="swit(7);">Object list</a> <br />
                <b>Quick links to references</b> <br />
                <a target="_blank" href="lang/statements.html">If statement</a>
                <a target="_blank" href="lang/statements.html">For loop</a>
                <a target="_blank" href="lang/statements.html">While loop</a> <br />
                <a target="_blank" href="lang/statements.html">Statements</a>
                <a target="_blank" href="lang/string.html">Strings</a>
                <a target="_blank" href="lang/math.html">Math</a>
                <a target="_blank" href="lang/database.html">Databases</a>
                <a target="_blank" href="lang/events.html">Events</a>
            </div>
            <div style="display:none;" id="tip-obj">
                <b>Quick links to object references</b> <br />
                <a target="_blank" href="lang/form.html">Form</a>
                <a target="_blank" href="lang/control.html">Textbox</a>
                <a target="_blank" href="lang/control.html">Button</a>
                <a target="_blank" href="lang/control.html">Password</a>
                <a target="_blank" href="lang/imagebox.html">Imagebox / Label</a>
                <a target="_blank" href="lang/checkbox.html">Checkbox</a>
             </div>
             <div style="display:none;" id="tip-for">
                 <b>For loop</b><br />
                 Syntax <br />
                 <pre><code>
                     For a = 0 To 10 Step 1
                         'Code
                     Next
                 </code></pre>
             </div>
             <div style="display:none;" id="tip-while">
                 <b>While loop</b><br />
                 Syntax <br />
                 <pre><code>
                     While ( cond = true)
                         'Code
                     End While
                 </code></pre>
             </div>
             <div style="display:none;" id="tip-if">
                 <b>If statement</b><br />
                 Syntax <br />
                 <pre><code>
                     If a > 0 Then
                         'Code
                     End If
                 </code></pre>
             </div>
             <div style="display:none;" id="tip-elseif">
                 <b>ElseIf</b><br />
                 Syntax <br />
                 <pre><code>
                     If m > 80 Then
                         'Code to excute if m greater than 80
                     ElseIf m >60 Then
                         'Code to excute if m greater than 60
                     End If
                 </code></pre>
             </div>
             <div style="display:none;" id="tip-else">
                 <b>Else</b><br />
                 Syntax <br />
                 <pre><code>
                     If m > 80 Then
                         'Code to excute if m greater than 80
                     Else
                         'Code to excute if m not greater than 80
                     End If
                 </code></pre>
             </div>
        </div>
        
        <script src="js/codemirror.min.js"></script>
        <script src="js/vb.min.js"></script>
        <script src="js/ide.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156056435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
