<?php

if(!isset($_POST["d"]) || empty($_POST["d"])){
    header("HTTP/1.0 404 Not Found");
    die();
}

include("dbs/mysql.php");
include("dbs/mysql_funs.php");

$data = $_POST["d"];
$obj = json_decode($data,true);

//var_dump($obj);
//die();
$name = validate_input($obj["name"]);
$email = validate_input($obj["email"]);

$out["code"] = 1;
$out["error"] = "unknown error";

function check_appname($name){
    global $conn,$out;
    $head = array("id");
    
    $where["app_name"] = $name;
    
    $query = select_table("apps",$head,$where);
    $result = mysqli_query($conn,$query);
    
    if(mysqli_num_rows($result)>0){
        $out["error"] = "App name already exsits";
        return false;
    }else{
        return true;
    }
}

function check_email($email){                                      
    //only a valid email
    //banned ips
    return true;
}

function get_random(){
    $rnd = rand(1000,10000);
    
    if(file_exists("../apps/".$rnd)){
        return get_random();
    }else{
        return $rnd;
    }
}

if(check_appname($name) && check_email($email)){
    $app_id = get_random();
    
    $expire = time() + (86400 *30);
    setcookie("app_id",$app_id,$expire,"/","",false,true);
    
    $st["app_id"] = $app_id;
    $st["email"] = $email;
    $st["app_name"] = $name;
    
    $query = insert_table("apps",$st);
    if(mysqli_query($conn,$query)){
        $out["code"] = 0;
    }else{
        $out["error"] = "Something went wrong";
    }
}

echo json_encode($out);

?>