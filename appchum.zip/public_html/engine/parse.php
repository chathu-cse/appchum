<?php

$out["code"] = 1;
$out["status"] = "Unknown error";

if(!isset($_POST["d"])){
    echo json_encode($out);
    die();
}

ini_set( 'session.cookie_httponly', 1 );
session_start();

$app_id= "";

if(isset($_SESSION["appname"])){
    $app_id = $_SESSION["appname"];
}elseif(isset($_COOKIE["token"])){
    include("dbs/mysql.php");
    include("dbs/mysql_funs.php");
    
    $hd = array("app_name");
    $wh["app_id"] = $_COOKIE["token"];
    
    $query = select_table("apps",$hd,$wh);
    $result = mysqli_query($conn,$query);
    
    $num = mysqli_num_rows($result);
    if($num == 1){
        $rows = mysqli_fetch_assoc($result);
        
        $app_id = $rows["app_name"];
        $_SESSION["appname"] = $rows["app_name"];
    }else{
        echo "error";
    }
}else{
    die("error redirect");
}

$data = $_POST["d"];
include("ele_creator.php");
include("compiler/code.php");

$matches = array();
$count = 0;


    $path = "../userfiles/".$app_id;
    if(!file_exists($path)){
        mkdir($path);
    }else{
        $ar = scandir($path);
        for($i=0;$i<count($ar);$i++){
            if(preg_match("/[^\.]+.html/",$ar[$i])){
                $count++;
                preg_match("/([^\.]+).html/",$ar[$i],$fun);
                $matches[] = $fun[1];
            }
        }
    }
    
    $project_file = $path."/project.json";
    $file = fopen($project_file,"w");
    fwrite($file,$data);

$obj = json_decode($data,true);

for($i=0;$i<count($obj);$i++){                                                
   $form =   $obj[$i];
   if($count >= 3 && !in_array($form["name"],$matches)){
       echo "<hr />Unable to create ".$form["name"]." ,Limit reached. If you need to create new app, overide one of these apps ->";
       foreach($matches as $val){
           echo " [".$val."] ";
       }
       break;
   }
   $content = "";
   for($j =0; $j<count($form["childs"]);$j++){
       $child = $form["childs"][$j];
       
       $content .= get_object($child);
   }
   //code stuf
   $all_code = all_code($form["childs"]);
   
   $urll = 'var urll = "back/'.$form["name"].'";
            var database = new Database("'.$app_id.'");
   ';
   $js_code = $urll.$all_code[0];
   $php_code = $all_code[1];
   //create form
   $file_content = createForm($form,$content,$js_code);
   $file_path = $path."/".$form["name"].".html";
   
   $file = fopen($file_path,"w");
   fwrite($file,$file_content);
   fclose($file);
   
   echo "<hr /> 😃 Your form <b>".$form["name"]."</b> is created with♥by Appchum <br />";
   echo '<a target="_blank" href="apps/'.$app_id.'/'.$form["name"].'" >View</a>';
   
   $file_path = $path."/".$form["name"].".php";
   
   $script = create_php($form["name"],$php_code);
   
   $file = fopen($file_path,"w");
   fwrite($file,$script);
   fclose($file);
   
   if($database_created){
       $file_path = $path."/".$form["name"].".xml";
   
       $script = '<database></database>';

       $file = fopen($file_path,"w");
       fwrite($file,$script);
       fclose($file); 
       
       echo "<hr />Your database <b>".$form["name"]."</b> is created with♥ by Appchum <br />";
       echo '<a target="_blank" href="databases/'.$app_id.'/'.$form["name"].'" >View</a>';
   }
   $database_created = false;
   $count ++;
   $matches[] = $form["name"];
}
?>