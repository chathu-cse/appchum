<?php

include("gui.php");
include("template.php");

function all_style($obj){
    $text = "";  
    
    $text .= eleWidth($obj["width"]);
    $text .= eleHeight($obj["height"]);
    $text .= cssTop($obj["topD"]);
    $text .= cssLeft($obj["leftD"]);
    $text .= cssBackcolor($obj["backcolor"]);
    $text .= cssBackimage($obj["backimage"]);
    $text .= cssCursor($obj["cursor"]);
    $text .= cssFont($obj["font"]);
    $text .= cssPadding($obj["padding"]);
    $text .= cssFontsize($obj["fontsize"]);
    $text .= cssFontcolor($obj["fontcolor"]);
    $text .= cssTextalign($obj["textalign"]);
    $text .= cssVisible($obj["notvisible"]);
    
    return $text;
}

function all_attributes($obj){
    $text = "";
    
    $text .= eleId($obj["name"]);
    $text .= btnText($obj["text"]);
    $text .= autoFocus($obj["autofocus"]);
    $text .= autoComplete($obj["autocomplete"]);
    $text .= tabIndex($obj["tabindex"]);
    $text .= eleDisabled($obj["disabled"]);
    $text .= 'class="ele"';
    
    return $text;
}

function createButton($obj){

    $style = eleStyle(all_style($obj));
    $attributes = all_attributes($obj).$style;
    
    $temp = '<input type="button"'.$attributes.' />';

    return $temp;
}
function createTextbox($obj){

    $style = eleStyle(all_style($obj));
    $attributes = all_attributes($obj).$style;
    
    $temp = '<input type="text"'.$attributes.' />';

    return $temp;
}

function createCheckbox($obj){

    $style = eleStyle(all_style($obj));
    $attributes = all_attributes($obj).$style;
    
    $num = rand(50,100);
    $id = "id='__".$obj["name"].$num."'";
    
    $for = "for='__".$obj["name"].$num."'";
    
    
    $temp = '<div {{attr}}>
    <input type="checkbox" {{id}}/> <label {{for}}>{{text}}</label>
    </div>';
    
    $bef = array("{{attr}}","{{id}}","{{for}}","{{text}}");
    $aff = array($attributes,$id,$for,$obj["text"]);
    $temp = str_replace($bef,$aff,$temp);

    return $temp;
}

function createImagebox($obj){

    $style = eleStyle(all_style($obj)."display:inline-block;");
    $attributes = all_attributes($obj).$style;
    
    $temp = '<div '.$attributes.' >'.$obj["text"].'</div>';

    return $temp;
}

function createPassword($obj){

    $style = eleStyle(all_style($obj));
    $attributes = all_attributes($obj).$style;
    
    $temp = '<input type="password"'.$attributes.' />';

    return $temp;
}

function form_style($obj){
    $text = "";  
    
    $text .= cssTop($obj["topD"]);
    $text .= cssLeft($obj["leftD"]);
    $text .= eleWidth($obj["width"]);
    $text .= eleHeight($obj["height"]);
    $text .= cssBackcolor($obj["backcolor"]);
    $text .= cssBackimage($obj["backimage"]);
    $text .= cssCursor($obj["cursor"]);

    return $text;
}

function form_attributes($fm){
    $text = "";
    
    
    return $text;
}

function createForm($fm,$cnt,$code){                                                              
    global $template;
    
    $title = formTitle($fm["title"]);
    $icon = formIcon($fm["icon"]);
    
    $style = eleStyle(form_style($fm));
    $attributes = form_attributes($fm).$style;
    
    $form = '<div id="form" '.$attributes.' >'.$cnt.'</div>';

    $bef = array("{{title}}","{{favicon}}","{{form}}","{{jscode}}");
    $aff = array($title,$icon,$form,$code);
    
    return str_replace($bef,$aff,$template);
    
    
}

function get_object($ty){
    switch($ty["type"]){
        case "button":
            return createButton($ty);
            break;
        case "textbox":
            return createTextbox($ty);
            break;
        case "checkbox":
            return createCheckbox($ty);
            break;
        case "imagebox":
            return createImagebox($ty);
            break;
        case "password":
            return createPassword($ty);
            break;
        default:
            return "";
            break;
    }
}

?>