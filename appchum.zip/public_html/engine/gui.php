<?php 

function formTitle($title){
    $text = "<title>".$title."</title>";
    
    return $text;
}

function formIcon($url){                                                  
    $text = '<link rel="icon" href="'.$url.'">';
    
    return $text;
}

function cssTop($in){
    $text = 'top:'.$in.'px;';
    
    return $text;
}

function cssLeft($in){
    $text = 'left:'.$in.'px;';
    
    return $text;
}

function eleStyle($sty){
    $text = "style='".$sty."'";
    
    return $text;
}

function eleWidth($wid){
    $text = "";
    
    if($wid != ""){
        $text = "width:".$wid."px;";
    }
    
    return $text;
}
function eleId($id){
    $text = "id='__".$id."'";
    
    return $text;
}

function eleHeight($hei){
    $text = "";
    
    if($hei != ""){
        $text = "height:".$hei."px;";
    }
    
    return $text;
}

function autoFocus($in){
    $text = "";
    if($in == 1){
        $texr = 'autofocus="true"';
    }
    
    return $text;
}

function autoComplete($in){
    $text = "";
    if($in == 1){
        $texr = 'autocomplete="true"';
    }
    
    return $text;
}

function tabIndex($in){
    $text ="";
    if($in != ""){
        $text = 'tabindex="'.$in.'"';
    }
    
    return $text;
}

function cssCursor($in){
    $text = "";
    
    if($in != ""){
        $text = 'cursor:'.$in.';';
    }
    return $text;
}

function eleDisabled($in){
    $text = "";
    
    if($in == 1){
        $text = 'disabled="true"';
    }
    
    return $text;
}

function btnText($txt){
    $text = "value='".$txt."'";
    
    
    return $text;
}

function cssBackcolor($clr){
    $text = "";
    
    if($clr != ""){
        $text = 'background-color:'.$clr.';';
    }
    
    return $text;
}

function cssBackimage($img){
    $text = "";
    
    if($img !=""){
        $text = 'background-image:("'.$img.'")';
    }
    
    return $text;
}

function cssPadding($pd){
    $text = "";
    
    if($pd != ""){
        $text = 'padding:'.$pd.'px;';
    }
    
    return $text;
}

function cssFont($fnt){
    $text = "";
    
    if($fnt != ""){
        $text = 'font-family:'.$fnt.';';
    }
    
    return $text;
}

function cssFontsize($fnt){
    $text = "";
    
    if($fnt != ""){
        $text = 'font-size:'.$fnt.'px;';
    }
    
    return $text;
}

function cssFontcolor($fnt){
    $text = "";
    
    if($fnt != ""){
        $text = 'color:'.$fnt.';';
    }
    
    return $text;
}

function cssVisible($fnt){
    $text = "";
    
    if($fnt == 1){
        $text = 'display:none;';
    }
    
    return $text;
}

function cssTextalign($fnt){
    $text = "";
    
    if($fnt != ""){
        $text = 'text-align:'.$fnt.';';
    }
    
    return $text;
}

function cssImagesize($wid,$hei){
    $text = "";
    
    if($wid != "" && $hei !=""){
        $text = 'background-size:'.$wid.'px '.$hei.'px;';
    }
    
    return $text;
}

function cssImagepos($wid,$hei){
    $text = "";
    
    if($wid != "" && $hei !=""){
        $text = 'background-position:'.$wid.'px '.$hei.'px;';
    }
    
    return $text;
}

?>