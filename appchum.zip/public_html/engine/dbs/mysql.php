<?php

//fill your mysql database details here

$user = "";
$host = "localhost";
$port="3306";
$password="";
$db="";

$conn = mysqli_connect($host, $user, $password, $db, $port);

if(!$conn){
    $out["error"] =1;
    $out["text"] ="System error:fatal";
    die(json_encode($out));
}

?>