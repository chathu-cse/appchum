<?php

function insert_table($table,$data){
    $heads ="";
    $values ="";
    $len = count($data);
    $i =1;
    
    foreach($data as $x=>$x_val){
        $heads.="`".$x."`";
        $values.="'".$x_val."'";
        if($i != $len){
            $heads.=",";
            $values.=",";
            $i++;
        }
    }
    
    $query = "INSERT INTO `"
    .$table.
    "`(".
    $heads.
    ") VALUES(".
    $values.")";
    
    return $query;
}

function update_table($table,$where,$sets){
    
    
    $args ="";
    $datas="";
    
    $whco = count($where);
    $i =1;
    $stco = count($sets);
    $j =1;
    
    foreach($where as $x=>$x_val){
        $term = "`".$x."`='".$x_val."'";
        $args.=$term;
        if($i!=$whco){
            $args.="&&";
            $i++;
        }
    }
    
    foreach($sets as $y=>$y_val){
        $term = "`".$y."`='".$y_val."'";
        $datas.=$term;
        if($j!=$stco){
            $datas.=",";
            $j++;
        }
    }
    
    $query = "UPDATE `".
    $table
    ."` SET ".
    $datas
    ." WHERE ".
    $args;
    
    return $query;
}

function select_table($table,$head,$where){
    $heads = "";
    $args = "";
    
    $hc = count($head);
    $wc = count($where);
    
    for($i =1;$i<=$hc;$i++){
        $heads.="`".$head[$i-1]."`";
        if($i != $hc){
            $heads.=",";
        }
    }
    
    $j = 1;
    foreach($where as $x => $x_value){
        $term = "`".$x."`='".$x_value."'";
        $args.=$term;
        if($j!=$wc){
            $args.=" && ";
            $j++;
        }
    }
    
    $query = "SELECT ".
    $heads
    ." FROM `".
    $table
    ."` WHERE ".
    $args;   
    
    return $query;
}

function valid($txt){
    return htmlspecialchars(trim($txt));
}
function reval($txt){
    return htmlspecialchars_decode($txt);
}



?>