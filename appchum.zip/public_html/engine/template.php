<?php
$template = '
<!DOCTYPE html><html><head><meta charset="utf-8" /> {{title}}{{favicon}}<meta name="viewport" content="width=device-width,initial-scale=1.0" /><style>body{margin:0px;padding:0px;}div{margin:0px;padding:0px;}#form{
                background-color:lightgray;
                border:2px solid black;
                display:inline-block;
                position:relative;
                width:70%;
                height:300px;
            }
            .ele{
                position:absolute;
            }
            #banner{
                position:fixed;
                bottom:0px;
            }
        </style>
    </head>
    <body>
    {{form}}
    <div id="banner"><h2>Created with <a href="https://appchum.com/?utm_source=appchum&utm_medium=banner&utm_campaign=init_banner&utm_content=bottom" target="_blank">Appchum</a></h2></div>
    <script src="../os.js"></script>
    <script>
     {{jscode}}
    </script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156056435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag("js", new Date());

  gtag("config", "UA-156056435-1");
</script>
</body>
</html>';


?>
