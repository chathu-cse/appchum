<?php

//String funs
$string = array();
$string["CharAt"] = "charAt()";
$string["Contains"] = "includes()";
$string["IndexOf"] = "indexOf()";
$string["Repeat"] = "repeat()";
$string["Substring"] = "substring()";
$string["Compare"] = "localeCompare()";
$string["ToUpper"] = "toUpperCase()";
$string["ToLower"] = "toLowerCase()";
$string["StartsWith"] = "startsWith()";
$string["EndsWith"] = "endsWith()";
$string["Slice"] = "slice()";
$string["Concat"] = "concat()";

$string["length"] = "length";

//forms
$forms["Title"] = "doc.title";
$forms["BackColor"] = "div.style.backgroundColor";
$forms["BackImage"] = "div.style.backgroundImage";
$forms["Cursor"] = "div.style.cursor";
$forms["Height"] = "div.style.height";
$forms["Width"] = "div.style.width";
$forms["Top"] = "div.style.top";
$forms["Left"] = "div.style.left";
$forms["Load"] = "doc.location";

//textbox, button,password funs
$textbox["Text"] = "value";
$textbox["FontColor"] = "style.color";
$textbox["AutoFocus"] = "autofocus";
$textbox["Disabled"] = "disabled";
$textbox["BackColor"] = "style.backgroundColor";
$textbox["TabIndex"] = "tabindex";
$textbox["BackImage"] = "style.backgroundImage";
$textbox["Cursor"] = "style.cursor";
$textbox["Padding"] = "style.padding";
$textbox["Font"] = "style.fontFamily";
$textbox["FontSize"] = "style.fontSize";
$textbox["Height"] = "style.height";
$textbox["Width"] = "style.width";
$textbox["TextAlign"] = "style.textAlign";
$textbox["Visible"] = "style.display";

//image box
$imagebox["Text"] = "textContent";
$imagebox["FontColor"] = "style.color";
$imagebox["BackColor"] = "style.backgroundColor";
$imagebox["BackImage"] = "style.backgroundImage";
$imagebox["Cursor"] = "style.cursor";
$imagebox["Padding"] = "style.padding";
$imagebox["Font"] = "style.fontFamily";
$imagebox["FontSize"] = "style.fontSize";
$imagebox["Height"] = "style.height";
$imagebox["Width"] = "style.width";
$imagebox["TextAlign"] = "style.textAlign";
$imagebox["Visible"] = "style.display";


//checkbox, label
$checkbox["Text"] = "lbl.textContent";
$checkbox["Checked"] = "in.checked";
$checkbox["Disabled"] = "in.disabled";
$checkbox["FontColor"] = "div.style.color";
$checkbox["BackColor"] = "div.style.backgroundColor";
$checkbox["BackImage"] = "div.style.backgroundImage";
$checkbox["Cursor"] = "div.style.cursor";
$checkbox["Padding"] = "div.style.padding";
$checkbox["Font"] = "div.style.fontFamily";
$checkbox["FontSize"] = "div.style.fontSize";
$checkbox["Height"] = "div.style.height";
$checkbox["Width"] = "div.style.width";
$checkbox["TextAlign"] = "div.style.textAlign";
$checkbox["Visible"] = "div.style.display";


//math
$math["Round"] = "round()";
$math["Abs"] = "abs()";
$math["Cos"] = "cos()";
$math["Sin"] = "sin()";
$math["Tan"] = "tan()";
$math["Floor"] = "round()";
$math["Ceil"] = "ceil()";
$math["Sqrt"] = "sqrt()";

//database

$database["Key"] = "key()";
$database["GetItem"] = "getItem()";
$database["SetItem"] = "setItem()";
$database["RemoveItem"] = "removeItem()";
$database["Clear"] = "clear()";
$database["Length"] = "length()";

//built in funs
$built["CStr"] = "String";
$built["CInt"] = "Number";


?>


