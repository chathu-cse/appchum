<?php
//memory
$js_code = array();

//stuff

include("php_lib.php");

function p_mt($ptn,$ch){
    return preg_match($ptn,$ch);
}
function p_inn($ch,$str){
    $ar = str_split($str);
    for($i=0;$i<count($ar);$i++){
        if($ar[$i] == $ch){
            return true;
        }
    }
    return false;
}

function p_proc_str($key,$ln){
    global $pstring,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pstring[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown string function:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    $ptn = "/^".$var."\.".$func."\((.+)\)$/";
    preg_match($ptn,$key,$insd);
        
    $functi = $pstring[$func];
    
    $inside  ="";
    if(isset($insd[1])){
        $inside =",".p_parse_expr($insd[1],$ln);
    }
    $text = $functi."(\$_".$var.$inside.")";
    return $text;
}

function p_proc_db($key,$ln){
    global $pdatabase,$errors,$database_created;

    $ptn = "/^Database\.([^\(]+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pdatabase[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown database function:".$fun[1]."in line ".$ln;
        return "";
    }
    
    $text = "";
    $ptn = "/^Database\.".$func."\((.+)\)$/";
    preg_match($ptn,$key,$insd);
        
    $functi = $pdatabase[$func];
    
    $inside  ="";
    if(isset($insd[1])){
        $inside =",".p_parse_expr($insd[1],$ln);
    }
    $text = $functi."(\$database".$inside.")";
    $database_created = true;
    return $text;
}
function p_proc_math($key,$ln){//edit
    global $pmath,$errors;

    $ptn = "/Math\.([^\(]+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pmath[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown math function:".$fun[1]."in line ".$ln;
        return "";
    }
    
    $text = "";
    $ptn = "/^Math\.".$func."\((.+)\)$/";
    preg_match($ptn,$key,$insd);
        
    $functi = $pmath[$func];
    
    $inside  ="";
    if(isset($insd[1])){
        $inside =p_parse_expr($insd[1],$ln);
    }
    $text = $functi."(".$inside.")";
    return $text;
}
function p_proc_txt($key,$ln){
    global $ptextbox,$errors,$js_code;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($ptextbox[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown object property:".$fun[1]."in line ".$ln;
        return "";
    }
    
    //js
    //"textbox.btn1.Text" : $btn1.value
    $pr_text = '"textbox.'.$var.".".$func.'"';
    $text = ":$".$var.".".$ptextbox[$func];
    $js_code[] = $pr_text.$text;
    //php
    //$obj["button.btn1.Text"]
    $text = "\$obj[".$pr_text."]";
    return $text;
}

function p_proc_check($key,$ln){
    global $pcheckbox,$errors,$js_code;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pcheckbox[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown checkbox property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $pr_text = '"checkbox.'.$var.".".$func.'"';
    $text = ":$".$var.".".$pcheckbox[$func];
    $js_code[] = $pr_text.$text;
    
    $text = "\$obj[".$pr_text."]";
    //echo $text;
    return $text;
}

function p_proc_form($key,$ln){
    global $pforms,$errors,$js_code;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pforms[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown form property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $pr_text = '"form.'.$var.".".$func.'"';
    $text = ":$".$var.".".$pforms[$func];
    $js_code[] = $pr_text.$text;
    
    $text = "\$obj[".$pr_text."]";
    //echo $text;
    return $text;
}

function p_proc_img($key,$ln){
    global $pimagebox,$errors,$js_code;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $func = "";
    if(isset($pimagebox[$fun[1]])){
        $func = $fun[1];
    }else{
        $errors[] = "Back:Unknown imagebox property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $pr_text = '"imagebox.'.$var.".".$func.'"';
    $text = ":$".$var.".".$pimagebox[$func];
    $js_code[] = $pr_text.$text;

    $text = "\$obj[".$pr_text."]";
    return $text;
}

function p_proc_fun($key,$ln){ //sjsjj.shjsj()
    global $obs,$errors;
    $ar = explode(".",$key);
    if(isset($obs[$ar[0]])){
        $type = $obs[$ar[0]];
        switch($type){
            case "String":
                return array(p_proc_str($key,$ln),"String");
                break;
            case "textbox":
                return array(p_proc_txt($key,$ln),"String");
                break;
            case "checkbox":
                return array(p_proc_check($key,$ln),"String");
                break; 
            case "form":
                return array(p_proc_form($key,$ln),"String");
                break;   
            case "imagebox":
                return array(p_proc_img($key,$ln),"String");
                break;   
            case "password":
                return array(p_proc_txt($key,$ln),"String");
                break;   
            case "button":
                return array(p_proc_txt($key,$ln),"String");
                break; 
            case "math":
                return array(p_proc_math($key,$ln),"Integer");
                break;    
            case "database":
                return array(p_proc_db($key,$ln),"String");
                break;                           
            default:
                //echo "type";
                $errors[] = "Illegal Data type:".$type;
                break;
        }
    }else{
        //echo "var";
        //print_r($obs);
        $errors[] = "Unknown variable:".$key;
    }
    
    return "";
}

function p_built_funs($word,$ln){
    global $pbuilt,$errors;
    
    preg_match("/^([\w_]+)\(/",$word,$fun);
    $ty = "String";
    if(isset($pbuilt[$fun[1]])){
        $function = $pbuilt[$fun[1]];
        preg_match("/^[\w_]+\((.+)\)$/",$word,$cnt);
        
        if($function == "intval"){
            $ty ="Integer";
        }
        return array($function."(".p_parse_expr($cnt[1],$ln).")",$ty);
    }else{
        $errors[] = "Back:Unknown built-in function:".$fun[1]." in line ".$ln;
        return array("","");
    }
}
$keywords = array("True","False","true","false","For","As","Then","Exist");

function p_check_keyword($word,$ln){
    global $keywords,$obs,$errors;
    if(in_array($word,$keywords)){
        return array($word,"String");
    }elseif(mt("/^[\w_]+\(/",$word)){
        return p_built_funs($word,$ln);
    }else{
        if(isset($obs[$word])){
            return array("\$_".$word,$obs[$word]);
        }else{
            $errors[] = "Back:Variable is not defined:".$word;
            return array("","");
        }
    }
}

function p_proc_key($key,$dot,$ln){
    if($dot){
        return p_proc_fun($key,$ln);
    }else{
        return p_check_keyword($key,$ln); //check key words -> true/...
    }
}

function p_parse_expr($expr,$ln){
    $out = "";
    $char_set = str_split($expr);
    $key = "";
    $pass = ""; // '' or ""
    $str = false; // is a string
    $dot = false;
    $count = count($char_set);
    $brak = 0;
    $prev = "";
    
    for($j=0;$j<$count;$j++){
        $c = $char_set[$j];
        if(p_mt("/[0-9]/",$c)){
            if($key == "" && $brak ==0){
                $out.=$c;
                $prev ="Integer";
            }else{
                $key.=$c;
            }
        }elseif(p_inn($c,"-/*%=,")){
            if($key != "" && $brak == 0){
                $ar= p_proc_key($key,$dot,$ln);
                $out .= $ar[0];
                $prev = $ar[1];
                $key = "";
                $dot = false;
            }
            if($brak == 0){
                $out .=$c;
                $prev = "Operator";
            }else{
                $key.=$c;
            }
        }elseif($c == "+"){
            if($key != "" && $brak == 0){
                $ar= p_proc_key($key,$dot,$ln);
                $out .= $ar[0];
                $prev = $ar[1];
                $key = "";
                $dot = false;
            }
            if($brak == 0){//the thing
                if($prev == "Integer"){
                    $out .="+";
                }else{
                    $out .=".";
                    $prev = ".";
                }
            }else{
                $key.=$c;
            }
        }elseif(p_mt("/[\(]/",$c)){ //think str open
            if($key != ""){
                $key .= $c;
                if(!$str){
                    $brak ++;
                }
            }else{
                $out .= $c;
            }
        }elseif(p_mt("/[\)]/",$c)){
            if($key != ""){
                $key .= $c;
                if(!$str){
                    $brak --;
                }
            }else{
                $out .= $c;
            }
        }elseif(p_mt("/[\s]/",$c)){
            if($key != "" && $brak ==0){
                $ar= p_proc_key($key,$dot,$ln);
                $out .= $ar[0];
                $prev = $ar[1];
                $key = "";
                $dot = false;
            }
            if($brak == 0){
                $out .= $c;
            }else{
                $key .= $c;
            }
        }elseif($c == "'" || $c == '"'){
            if($pass == ""){
                $pass = $c;
                $str = true;
            }elseif($c == $pass){
                $pass = "";
                $str = false;
            }
            if($brak == 0){
                $out .= $c;
                $prev = $c;
            }else{
                $key .= $c;
            }
        }elseif(p_mt("/[a-zA-Z]/",$c)){
            if($str && $brak ==0){
                $out.=$c;
            }else{
                $key .= $c;
            }
        }elseif(p_mt("/\./",$c)){
            if($str){
                $out .= $c;
                $prev = $c;
            }else{
                $key .= $c;
                if($brak ==0){
                    $dot = true;
                }
            }
        }else{
            if($brak ==0){
                $out .= $c;
                $prev = $c;
            }else{
                $key .= $c;
            }
        }
        //end
        if($j == ($count - 1)){
            if($key != ""){
                $ar= p_proc_key($key,$dot,$ln);
                $out .= $ar[0];
                $prev = $ar[1];
            }
        }
    }
    
    return $out;
}

//vars 
function p_parse_var($str,$ln){
    global $obs;
    /*
    Dim he,kj as String -> var he,kj;
    Dim hs as String = "helo" -> var hs = "helo";                                                                                          
    */
    $ptn = "/\s*Dim\s+(.+)\s+As/";
    preg_match($ptn,$str,$id_str);
    
    $ptn = "/As\s+(String|Integer|Boolean)\s*=?/";
    preg_match($ptn,$str,$type);
    $out_list = "";
    //adding to arrays
    $id_arr = explode(",",$id_str[1]);
    $ids = count($id_arr);
    for($l =0;$l<$ids;$l++){
        $var = $id_arr[$l];
        $obs[$var] = $type[1];
        $out_list.= "\$_".$var;
        if($l != ($ids-1)){
            $out_list.=",";
        }
    }
    
    $ptn = "/\s=\s+(.+)\s*$/";
    preg_match($ptn,$str,$cnt);
    
    $ot = "";
    if(isset($cnt[1])){
        $ot = $out_list." = ".p_parse_expr($cnt[1],$ln).";";
    }else{
        $ot = $out_list.";";
    }
    return $ot;
}

function p_parse_if($str,$ln){
    $ptn = "/^\s*If\s+(.+)\s+Then\s*$/";
    preg_match($ptn,$str,$res);
    $out = "if(".p_parse_expr($res[1],$ln)."){";
    
    return $out;
}

function p_parse_elseif($str,$ln){
    $ptn = "/^\s*ElseIf\s+(.+)\s+Then\s*$/";
    
    preg_match($ptn,$str,$res);
    
    $out = "}elseif(".p_parse_expr($res[1],$ln)."){";
    
    return $out;
}

function p_parse_for($str,$ln){
    /*
    For start =0 To 10 Step 4
       Body
    Next
    for(var st=0;st<(st+10);st+=4){
        
    }
    */
    $ptn = "/^\s*For\s+(.+)\s+To/";
    preg_match($ptn,$str,$var_str);
    $var_arr = explode("=",$var_str[1]);
    $vr = trim($var_arr[0]);
    $st_val = trim($var_arr[1]);
    
    $ptn = "/To\s+(\d+)\s+Step/";
    preg_match($ptn,$str,$to_arr);
    $to = $to_arr[1];
    
    $ptn = "/Step\s+(\d+)\s*$/";
    preg_match($ptn,$str,$step_ar);
    $step = $step_ar[1];
    
    $text = "for(\$_".$vr."=".$st_val.";\$_".$vr."<(\$_".$vr."+".$to.");\$_".$vr."+=".$step."){";
    return $text;
    
}

function p_parse_while($str,$ln){
    $ptn = "/^\s*While\s*\((.+)\)\s*/";
    preg_match($ptn,$str,$exp_ar);
    $expr = p_parse_expr($exp_ar[1],$ln);
    
    $text = "while(".$expr."){";
    return $text;
}

function parse_php($code){
    global $js_code,$errors;
    $js_code = array();
    $arr = preg_split("/[\n]+/",$code);
    $out = "";

    for($i=0;$i<count($arr);$i++){
        $line = $arr[$i];
        if(p_mt("/^\s*Dim\s+/",$line)){
            $out .= p_parse_var($line,$i+1);
        }elseif(p_mt("/^\s*If\s+/",$line)){
            $out .= p_parse_if($line,$i+1);
        }elseif(p_mt("/^\s*End If\s*$/",$line) || p_mt("/^\s*Next\s*$/",$line) || p_mt("/\s*End While\s*/",$line)){
            $out .= "}";
        }elseif(p_mt("/^\s*ElseIf\s+/",$line)){
            $out .= p_parse_elseif($line,$i+1);
        }elseif(p_mt("/^\s*Else\s*$/",$line)){
            $out .= "}else{";
        }elseif(p_mt("/^\s*For\s+/",$line)){
            $out .= p_parse_for($line,$i+1);
        }elseif(p_mt("/^\s*While\s*\(/",$line)){
            $out .= p_parse_while($line, $i+1);
        }elseif(p_mt("/^'/",$line)){
            $out .= "/*".$line."*/";
        }else{
            $out .= p_parse_expr($line,$i+1).";";
        }
    }
    /*
    for($m =0;$m<count($errors);$m++){
        echo "😕 ".$errors[$m]."<br />";
    } */   
    return array($js_code,$out);
}
?>