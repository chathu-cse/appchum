<?php
$pstring = array();
$pstring["CharAt"] = "char_at";//
$pstring["Contains"] = "str_contains";//
$pstring["IndexOf"] = "strpos";
$pstring["Repeat"] = "str_repeat";
$pstring["Substring"] = "substr";
$pstring["Compare"] = "strcmp";
$pstring["ToUpper"] = "strtoupper";
$pstring["ToLower"] = "strtolower";
$pstring["StartsWith"] = "starts_with";
$pstring["EndsWith"] = "ends_ith";
$pstring["Slice"] = "substr";
$pstring["Concat"] = "str_concat";

$pstring["length"] = "strlen";

$pforms["Title"] = "doc.title";
$pforms["BackColor"] = "div.style.backgroundColor";
$pforms["BackImage"] = "div.style.backgroundImage";
$pforms["Cursor"] = "div.style.cursor";
$pforms["Height"] = "div.style.height";
$pforms["Width"] = "div.style.width";
$pforms["Top"] = "div.style.top";
$pforms["Left"] = "div.style.left";
$pforms["Load"] = "doc.location";

//textbox, button,password funs
$ptextbox["Text"] = "value";
$ptextbox["FontColor"] = "style.color";
$ptextbox["AutoFocus"] = "autofocus";
$ptextbox["Disabled"] = "disabled";
$ptextbox["BackColor"] = "style.backgroundColor";
$ptextbox["TabIndex"] = "tabindex";
$ptextbox["BackImage"] = "style.backgroundImage";
$ptextbox["Cursor"] = "style.cursor";
$ptextbox["Padding"] = "style.padding";
$ptextbox["Font"] = "style.fontFamily";
$ptextbox["FontSize"] = "style.fontSize";
$ptextbox["Height"] = "style.height";
$ptextbox["Width"] = "style.width";
$ptextbox["TextAlign"] = "style.textAlign";
$ptextbox["Visible"] = "style.display";

//image box
$pimagebox["Text"] = "textContent";
$pimagebox["FontColor"] = "style.color";
$pimagebox["BackColor"] = "style.backgroundColor";
$pimagebox["BackImage"] = "style.backgroundImage";
$pimagebox["Cursor"] = "style.cursor";
$pimagebox["Padding"] = "style.padding";
$pimagebox["Font"] = "style.fontFamily";
$pimagebox["FontSize"] = "style.fontSize";
$pimagebox["Height"] = "style.height";
$pimagebox["Width"] = "style.width";
$pimagebox["TextAlign"] = "style.textAlign";
$pimagebox["Visible"] = "style.display";


//checkbox, label
$pcheckbox["Text"] = "lbl.textContent";
$pcheckbox["Checked"] = "in.checked";
$pcheckbox["Disabled"] = "in.disabled";
$pcheckbox["FontColor"] = "div.style.color";
$pcheckbox["BackColor"] = "div.style.backgroundColor";
$pcheckbox["BackImage"] = "div.style.backgroundImage";
$pcheckbox["Cursor"] = "div.style.cursor";
$pcheckbox["Padding"] = "div.style.padding";
$pcheckbox["Font"] = "div.style.fontFamily";
$pcheckbox["FontSize"] = "div.style.fontSize";
$pcheckbox["Height"] = "div.style.height";
$pcheckbox["Width"] = "div.style.width";
$pcheckbox["TextAlign"] = "div.style.textAlign";
$pcheckbox["Visible"] = "div.style.display";

//math
$pmath["Round"] = "round";
$pmath["Abs"] = "abs";
$pmath["Cos"] = "cos";
$pmath["Sin"] = "sin";
$pmath["Tan"] = "tan";
$pmath["Floor"] = "round";
$pmath["Ceil"] = "ceil";
$pmath["Sqrt"] = "sqrt";

//database

$pdatabase["Length"] = "get_length";
$pdatabase["Key"] = "get_key";
$pdatabase["GetItem"] = "get_item";
$pdatabase["SetItem"] = "set_item";
$pdatabase["RemoveItem"] = "remove_item";
$pdatabase["Clear"] = "db_clear";

//built in functions
$pbuilt["CInt"] = "intval";
$pbuilt["CStr"] = "strval";

?>