<?php

//memory
$obs = array();
$obs["Math"] = "math";
$obs["Database"] = "database";
$obs["Form"] = "form";

$errors = array();
$database_created = false;
//stuf

include("js_lib.php");

function mt($ptn,$ch){
    return preg_match($ptn,$ch);
}
function inn($ch,$str){
    $ar = str_split($str);
    for($i=0;$i<count($ar);$i++){
        if($ar[$i] == $ch){
            return true;
        }
    }
    return false;
}

function proc_str($key,$ln){
    global $string,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($string[$fun[1]])){
        $func = $fun[1];
        if(strpos($string[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown string function:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^".$var."\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$string[$func]);
        $text = "$".$var.".".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "$".$var.".".$string[$func];
    }
    return $text;
}

function proc_math($key,$ln){//edit
    global $math,$errors;

    $ptn = "/^Math\.([^\(]+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($math[$fun[1]])){
        $func = $fun[1];
        //echo $math[$fun[1]];
        if(strpos($math[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown Math function:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^Math\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$math[$func]);
        $text = "Math.".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        //echo "sttange";
        $text = "Math.".$math[$func];
    }
    return $text;
}

function proc_db($key,$ln){//edit
    global $database,$errors;

    $ptn = "/^Database\.(\w+)\(/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($database[$fun[1]])){
        $func = $fun[1];
        if(strpos($database[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown database function:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^Database\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        //print_r($insd);
        if(empty($insd)){
            $insd[1]="";
        }
        $functi = str_replace("()","",$database[$func]);
        $text = "database.".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "database.".$database[$func];
    }
    return $text;
}

function proc_txt($key,$ln){
    global $textbox,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($textbox[$fun[1]])){
        $func = $fun[1];
        if(strpos($textbox[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown object property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^".$var."\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$textbox[$func]);
        $text = "$".$var.".".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "$".$var.".".$textbox[$func];
    }
    return $text;
}

function proc_check($key,$ln){
    global $checkbox,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($checkbox[$fun[1]])){
        $func = $fun[1];
        if(strpos($checkbox[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown checkbox property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^".$var."\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$checkbox[$func]);
        $text = "$".$var.".".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "$".$var.".".$checkbox[$func];
    }
    return $text;
}

function proc_form($key,$ln){
    global $forms,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($forms[$fun[1]])){
        $func = $fun[1];
        if(strpos($forms[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown form property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^".$var."\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$forms[$func]);
        $text = "$".$var.".".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "$".$var.".".$forms[$func];
    }
    return $text;
}

function proc_img($key,$ln){
    global $imagebox,$errors;
    $arr = explode(".",$key);
    $var = $arr[0];
    
    $ptn = "/^".$var."\.([^\(]+)\(?/";
    preg_match($ptn,$key,$fun);
    
    //print_r($fun);
    $prop = false;
    $func = "";
    if(isset($imagebox[$fun[1]])){
        $func = $fun[1];
        if(strpos($imagebox[$fun[1]],"()") !== false){
            $prop = false;
        }else{
            $prop = true;
        }
    }else{
        $errors[] = "Front:Unknown imagebox property:".$fun[1]." in line ".$ln;
        return "";
    }
    
    $text = "";
    if(!$prop){
        $ptn = "/^".$var."\.".$func."\((.+)\)$/";
        preg_match($ptn,$key,$insd);
        
        $functi = str_replace("()","",$imagebox[$func]);
        $text = "$".$var.".".$functi."(".parse_expr($insd[1],$ln).")";
    }else{
        $text = "$".$var.".".$imagebox[$func];
    }
    return $text;
}

function proc_fun($key,$ln){ //sjsjj.shjsj()
    global $obs,$errors;
    $ar = explode(".",$key);
    if(isset($obs[$ar[0]])){
        $type = $obs[$ar[0]];
        switch($type){
            case "String":
                return proc_str($key,$ln);
                break;
            case "textbox":
                return proc_txt($key,$ln);
                break;
            case "checkbox":
                return proc_check($key,$ln);
                break;  
            case "form":
                return proc_form($key,$ln);
                break;   
            case "imagebox":
                return proc_img($key,$ln);
                break;   
            case "password":
                return proc_txt($key,$ln);
                break;   
            case "button":
                return proc_txt($key,$ln);
                break;  
            case "math":
                return proc_math($key,$ln);
                break;
            case "database":
                return proc_db($key,$ln);
                break;            
            default:
                //echo "type";
                $errors[] = "Illegal Data type:".$type;
                break;
        }
    }else{
        //echo "var";
        //print_r($obs);
        $errors[] = "Unknown variable:".$key;
    }
    
    return "";
}

function built_funs($word,$ln){
    global $built,$errors;
    
    preg_match("/^([\w_]+)\(/",$word,$fun);
    
    if(isset($built[$fun[1]])){
        $function = $built[$fun[1]];
        preg_match("/^[\w_]+\((.+)\)$/",$word,$cnt);
        
        return $function."(".parse_expr($cnt[1],$ln).")";
    }else{
        $errors[] = "Front:Unknown built-in function:".$fun[1]." in line ".$ln;
        return "";
    }
}

$keywords = array("True","False","true","false","For","As","Then","Exist");

function check_keyword($word,$ln){
    global $keywords;
    if(in_array($word,$keywords)){
        return $word;
    }else{
        if(mt("/^[\w_]+\(/",$word)){
            return built_funs($word,$ln);
        }else{
            return "$".$word;
        }
    }
}

function proc_key($key,$dot,$ln){
    
    if($dot){
        return proc_fun($key,$ln);
    }else{
        return check_keyword($key,$ln); //check key words -> true/...
    }
}

function parse_expr($expr,$ln){
    $out = "";
    $char_set = str_split($expr);
    $key = "";
    $pass = ""; // '' or ""
    $str = false; // is a string
    $dot = false;
    $count = count($char_set);
    $brak = 0;
    
    for($j=0;$j<$count;$j++){
        $c = $char_set[$j];
        if(mt("/[0-9]/",$c)){
            if($key == "" && $brak ==0){
                $out.=$c;
            }else{
                $key.=$c;
            }
        }elseif(inn($c,"+-/*%=,")){
            if($key != "" && $brak == 0){
                $out .= proc_key($key,$dot,$ln);
                $key = "";
                $dot = false;
            }
            if($brak == 0){
                $out .=$c;
            }else{
                $key.=$c;
            }
        }elseif(mt("/[\(]/",$c)){ //think str open
            if($key != ""){
                $key .= $c;
                if(!$str){
                    $brak ++;
                }
            }else{
                $out .= $c;
            }
        }elseif(mt("/[\)]/",$c)){
            if($key != ""){
                $key .= $c;
                if(!$str){
                    $brak --;
                }
            }else{
                $out .= $c;
            }
         }elseif(mt("/[\s]/",$c)){
            if($key != "" && $brak ==0){
                $out .= proc_key($key,$dot,$ln);
                $key = "";
                $dot = false;
            }
            if($brak == 0){
                $out .= $c;
            }else{
                $key .= $c;
            }
        }elseif($c == "'" || $c == '"'){
            if($pass == ""){
                $pass = $c;
                $str = true;
            }elseif($c == $pass){
                $pass = "";
                $str = false;
            }
            if($brak == 0){
                $out .= $c;
            }else{
                $key .= $c;
            }
        }elseif(mt("/[a-zA-Z]/",$c)){
            if($str && $brak ==0){
                $out.=$c;
            }else{
                $key .= $c;
            }
        }elseif(mt("/\./",$c)){
            if($str){
                $out .= $c;
            }else{
                $key .= $c;
                if($brak ==0){
                    $dot = true;
                }
            }
        }else{
            if($brak ==0){
                $out .= $c;
            }else{
                $key .= $c;
            }
        }
        //end
        if($j == ($count - 1)){
            if($key != ""){
                $out .= proc_key($key,$dot,$ln);
            }
        }
    }
    
    return $out;
}

//vars 
function parse_var($str,$ln){
    global $obs;
    /*
    Dim he,kj as String -> var he,kj;
    Dim hs as String = "helo" -> var hs = "helo";                                                                                          
    */
    $ptn = "/\s*Dim\s+(.+)\s+As/";
    preg_match($ptn,$str,$id_str);
    
    $ptn = "/As\s+(String|Integer)\s*=?/";
    preg_match($ptn,$str,$type);
    $out_list = "";
    //adding to arrays
    $id_arr = explode(",",$id_str[1]);
    $ids = count($id_arr);
    for($l =0;$l<$ids;$l++){
        $var = $id_arr[$l];
        $obs[$var] = $type[1];
        $out_list.= "$".$var;
        if($l != ($ids-1)){
            $out_list.=",";
        }
    }
    
    $ptn = "/\s=\s+(.+)\s*$/";
    preg_match($ptn,$str,$cnt);
    
    $ot = "";
    if(isset($cnt[1])){
        $ot = "var ".$out_list." = ".parse_expr($cnt[1],$ln).";";
    }else{
        $ot = "var ".$out_list.";";
    }
    return $ot;
}

function parse_if($str,$ln){
    $ptn = "/^\s*If\s+(.+)\s+Then\s*$/";
    preg_match($ptn,$str,$res);
    $out = "if(".parse_expr($res[1],$ln)."){";
    
    return $out;
}

function parse_elseif($str,$ln){
    $ptn = "/^\s*ElseIf\s+(.+)\s+Then\s*$/";
    
    preg_match($ptn,$str,$res);
    
    $out = "}else if(".parse_expr($res[1],$ln)."){";
    
    return $out;
}

function parse_for($str,$ln){
    /*
    For start =0 To 10 Step 4
       Body
    Next
    for(var st=0;st<(st+10);st+=4){
        
    }
    */
    $ptn = "/^\s*For\s+(.+)\s+To/";
    preg_match($ptn,$str,$var_str);
    $var_arr = explode("=",$var_str[1]);
    $vr = trim($var_arr[0]);
    $st_val = trim($var_arr[1]);
    
    $ptn = "/To\s+(.+)\s+Step/";
    preg_match($ptn,$str,$to_arr);
    $to = parse_expr($to_arr[1],$ln);
    
    $ptn = "/Step\s+(\d+)\s*$/";
    preg_match($ptn,$str,$step_ar);
    $step = parse_expr($step_ar[1],$ln);
    
    $text = "for(var $".$vr."=".$st_val.";$".$vr."<".$to.";$".$vr."+=".$step."){";
    return $text;
    
}

function parse_while($str,$ln){
    $ptn = "/^\s*While\s*\((.+)\)\s*/";
    preg_match($ptn,$str,$exp_ar);
    $expr = parse_expr($exp_ar[1],$ln);
    
    $text = "while(".$expr."){";
    return $text;
}

function parse_js($code){
    global $errors;
    $arr = preg_split("/[\n]+/",$code);
    $out = "";

    for($i=0;$i<count($arr);$i++){
        $line = $arr[$i];

        if(mt("/^\s*Dim\s+/",$line)){
            $out .= parse_var($line,$i+1);
        }elseif(mt("/^\s*If\s+/",$line)){
            $out .= parse_if($line,$i+1);
        }elseif(mt("/^\s*End If\s*$/",$line) || mt("/^\s*Next\s*$/",$line) || mt("/\s*End While\s*/",$line)){
            $out .= "}";
        }elseif(mt("/^\s*ElseIf\s+/",$line)){
            $out .= parse_elseif($line,$i+1);
        }elseif(mt("/^\s*Else\s*$/",$line)){
            $out .= "}else{";
        }elseif(mt("/^\s*For\s+/",$line)){
            $out .= parse_for($line,$i+1);
        }elseif(mt("/^\s*While\s*\(/",$line)){
            $out .= parse_while($line, $i+1);
        }elseif(mt("/^'/",$line)){
            $out .= "/*".$line."*/";
        }else{
            $out .= parse_expr($line,$i+1).";";
        }
        
    }
    /////
    /*
    for($m =0;$m<count($errors);$m++){
        echo "   😞    ".$errors[$m]."<br />";
    }*/
    /////
    return $out;
}





?>