<?php

include("compile.php");
include("compile_php.php");

$js_event_tmp ='
${{name}}.addEventListener("{{event}}",function(e){
    e.stopPropagation();
    {{code}}
});
';

$php_event_tmp ='
${{name}}.addEventListener("{{event}}",function(e){
    e.stopPropagation();
    var obj = {
        "for":"{{for}}",
        {{code}}
    };
    send_data(obj,urll);
});
';
$php_case = '
case "{{for}}":
    {{code}}
    break;
';

$js_reciever = '
function reciever(res){
    var dobj = JSON.parse(res);

    switch(dobj["for"]){
        {{code}}
        default:
            //imposi
            break;
    }
}
';

/* jjjjjjjjjjjjjjjjj ssssssssssssss */

function compile_js($ev,$ty){
    global $js_event_tmp,$errors;
    
    $nm = "";
    if($ty != "checkbox"){
        $nm = $ev["object"];
    }else{
        $nm = $ev["object"].".in";
    }
    
    $event = $ev["event"];
    if($ev["code"] == ""){
        return "";
    }
    
    echo "<hr /> <b>".$ev["scope"]."|".$ev["object"]."|".$ev["event"]."</b> <br />";
    
    $code = parse_js($ev["code"]);  
    
    for($m =0;$m<count($errors);$m++){
        echo "😞 ".$errors[$m]."<br />";
    }
    if(count($errors) == 0){
        echo "No errors. 😎";
    }
    $errors = array();
    
    $bef = array("{{name}}","{{event}}","{{code}}");
    $aff = array($nm,$event,$code);
    $out = str_replace($bef,$aff,$js_event_tmp);
    return $out;
}

/* ppppppp hhhhhhh ppppppp */

function flip_code($code){
    $arr = explode(":",$code,2);
    
    $out = $arr[1].'=dobj['.$arr[0].'];';
    return $out;
}

function compile_php($ev,$ty){
    global $php_event_tmp,$php_case,$errors;
    $forr = rand(100,10000);
    
    
    $nm = "";
    if($ty != "checkbox"){
        $nm = $ev["object"];
    }else{
        $nm = $ev["object"].".in";
    }
    
    $event = $ev["event"];
    if($ev["code"] == ""){
        return array("","","");
    }
    
    echo "<hr /> <b>".$ev["scope"]."|".$ev["object"]."|".$ev["event"]."</b> <br />";
    
    $arr = parse_php($ev["code"]);
    
    for($m =0;$m<count($errors);$m++){
        echo " 😞 ".$errors[$m]."<br />";
    }
    
    if(count($errors) == 0){
        echo "No errors. 😎";
    }
    
    $errors = array();
    
    $arr = parse_php($ev["code"]);
    $js_arr = $arr[0];
    $php = $arr[1];
    $js = "";
    $res_js = "";

    $js_n = count($js_arr);
    for($k =0;$k<$js_n;$k++){
        $js .= $js_arr[$k];
        $res_js .= flip_code($js_arr[$k]);
        if($k != $js_n -1){
            $js .= ",";
        }
    }
    
    $bef = array("{{name}}","{{event}}","{{for}}","{{code}}");
    $aff = array($nm,$event,$forr,$js);
    $out = str_replace($bef,$aff,$php_event_tmp);
    
    $bef = array("{{for}}","{{code}}");
    $aff = array($forr,$php);
    $fin = str_replace($bef,$aff,$php_case);
    
    //reciver
    $bef = array("{{for}}","{{code}}");
    $aff = array($forr,$res_js);
    $loader = str_replace($bef,$aff,$php_case);
    
    return array($out,$fin,$loader);
}

function turn_code($ev,$typ){
    if($ev["scope"] =="front"){
        return array(compile_js($ev,$typ),"","");
    }else{
        return compile_php($ev,$typ);
    }
}

function setup_ident($typ,$nam){
    $tmp = "document.getElementById('__{{name}}')";
    $chk = "= new CheckBox({{ele}});";
    
    $out = "var $".$nam;
    
    if($typ == "checkbox"){
        $gt = str_replace("{{name}}",$nam,$tmp);
        $out .= str_replace("{{ele}}",$gt,$chk);
    }else{
        $gt = str_replace("{{name}}",$nam,$tmp);
        $out .= "=".$gt.";";
    }
    return $out;
}

function all_code($childs){
    global $obs,$js_reciever;
    $init = "var form = document.getElementById('form');";
    $the_code = "";
    $the_php = "";
    $the_res = "";
    
    for($j=0;$j<count($childs);$j++){
        $chi = $childs[$j];
        $obs[$chi["name"]] = $chi["type"];
    }
    
    for($i =0;$i<count($childs);$i++){
        $child = $childs[$i];
        $init .= setup_ident($child["type"],$child["name"]);
        
        $events = $child["events"];
        for($j =0;$j<count($events);$j++){
            $event = $events[$j];
            $arr= turn_code($event,$child["type"]);
            $the_code .= $arr[0];
            $the_php  .= $arr[1];
            $the_res .= $arr[2];
        }
    }
    
    $zzz = str_replace("{{code}}",$the_res,$js_reciever);
    
    return array($init.$the_code.$zzz,$the_php);//rec
}

//php file struc
$php_template = '
<?php
$data = $_POST["d"];
$obj = json_decode($data,true);
include("../libraries.php");
$database = "{{db}}.xml";
switch($obj["for"]){
    {{allcode}}
    default:
        //imposible, error log
        break;
}
echo json_encode($obj);
?>
';

function create_php($nm,$cd){
    global $php_template;
    
    return str_replace(["{{db}}","{{allcode}}"],[$nm,$cd],$php_template);
}

?>

