<?php
if(isset($_GET["id"])){
    $rawid= $_GET["id"];
    $id = "";
    
    if(preg_match("/^\d+$/",$rawid)){
        $id = $rawid;
    }elseif(preg_match("/^\d+\?./",$rawid)){
        preg_match("/^(\d+)\?./",$rawid,$mat);
        $id = $mat[1];
    }else{
        die("<h1>Something went wrong</h1>");
    }
    
    include("../engine/dbs/mysql.php");
    include("../engine/dbs/mysql_funs.php");
    
    $hd = array("title","date","by","short","content");
    $wh["hash"] = $id;
    
    $query = select_table("posts",$hd,$wh);
    $result = mysqli_query($conn,$query);
    
    if(mysqli_num_rows($result) == 0){
        die("<h1>Post doesn't exists.</h1>");
    }
    
    $row = mysqli_fetch_assoc($result);

    $title = reval($row["title"]);
    $date = reval($row["date"]);
    $by = reval($row["by"]);
    $short = reval($row["short"]);
    $content = reval($row["content"]);
    
}else{
    die("<h1>Page not found</h1>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <title><?php echo $title; ?> - Appchum</title>
  <meta name="description" content="<?php echo $short; ?>">
  <meta name="author" content="<?php echo $by; ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://appchum.com/css/skeleton.css">
  <link rel="stylesheet" href="https://appchum.com/css/vs.css">
  <link rel="icon" type="image/ico" href="https://appchum.com/images/favicon.ico">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="twelve columns">
                <h6><a href="/">Appchum</a> &gt; <a href="https://appchum.com/blog">Blog</a></h6>
                <h2><?php echo $title; ?></h2>
                <h6>on <?php echo $date; ?> | by <?php echo $by; ?></h6>
                <?php echo $content; ?>
                <h6>Back to <a href="https://appchum.com/blog">blog</a>.</h6>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="twelve columns">
                <center>
                    <a href="/">Home page</a> |
                    <a href="https://appchum.com/apps/app/feedback">Feedback</a> |
                    <a href="https://appchum.com/apps/app/join">Join</a> |
                    <a href="https://appchum.com/privacy.html">Privacy policy</a> |
                    <a href="https://appchum.com/terms.html">Terms and conditions</a> |
                    <a href="https://appchum.com/about.html">About</a>
                </center>
            </div>
        </div>
    </div>
    <script src="https://appchum.com/js/highlight.pack.js"></script>
    <script>hljs.initHighlightingOnLoad();</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156056435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156056435-1');
</script>
</body>
</html>
    