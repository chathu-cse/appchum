<?php
if(isset($_GET["appname"])){   
    ini_set( 'session.cookie_httponly', 1 );
    session_start();
    
    if(isset($_POST["logout"])){
        session_unset();
        session_destroy();
        die("<h1>Succeed.</h1> To <a href='/'>Home page</a>");
    }
    
    include("../engine/dbs/mysql.php");
    include("../engine/dbs/mysql_funs.php");
    
    $show_login = true;
    $show_dash = false;
    $show_db = false;
    
    $tb_out = "";
    
    if(isset($_SESSION["atempt"])){
        die("<h1>Access denied.</h1><h5>Try again later.</h5>");
    }
    
    if(isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["login"])){
        $hd = array("password");
        $wh["app_name"] = strtolower($_GET["appname"]);
        $wh["email"] = strtolower($_POST["email"]);

        $query = select_table("apps",$hd,$wh);
        $result = mysqli_query($conn,$query);
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            
            if(password_verify($_POST["password"],$row["password"])){
                $show_login = false;
                $show_dash = true;
                $_SESSION["app_id"] = $_GET["appname"];
            }else{
                $_SESSION["atempt"] = 1;
                die("<h1>Access denied.</h1><h5>Try again later.</h5>");
            }
        }else{
            $_SESSION["atempt"] = 1;
            die("<h1>Access denied.</h1><h5>Try again later.</h5>");
        }
    }
    
    //render data
    if(isset($_SESSION["app_id"])){
        $show_login = false;
        $show_dash = true;
        $app_path = "../userfiles/".$_SESSION["app_id"];
        $all_files = scandir($app_path);
        
        $db_list = "";
        $temp ='<a href="https://appchum.com/databases/{{app}}/{{name}}" class="button">{{name}}</a>';
        foreach($all_files as $file){
            if(preg_match("/[^\.]+.xml/",$file)){
                preg_match("/([^\.]+).xml/",$file,$match);
                $befff = array("{{app}}","{{name}}");
                $affff = array($_SESSION["app_id"],$match[1]);
                $db_list .= str_replace($befff,$affff,$temp);
            }
        }
        
        if(isset($_GET["db"])){
            $db_path = $app_path."/".$_GET["db"].".xml";
            if(file_exists($db_path)){
                $show_db = true;
                $xml = simplexml_load_file($db_path);
                $list = $xml->row;
                $list_nm = count($list);
                
                $temp2 = '<tr><td>{{key}}</td><td>{{value}}</td></tr>';
                if($list_nm != 0){
                    for($k=0;$k<$list_nm;$k++){
                        $aff = array($list[$k]->key,$list[$k]->value);
                        $bef = array("{{key}}","{{value}}");
                        $tb_out .= str_replace($bef,$aff,$temp2);
                    }
                }else{
                    // no record found
                }
            }else{
                // cant find db
            }
        }
    }else{
        $show_login = true;
        $show_dash = false;
        $show_db = false;
    }
    
}else{
    die("<h1>404 Page not found </h1>");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Databases</title>
  <meta name="description" content="Access databases used in Appchum">
  <meta name="author" content="Dumindu Chathuranga">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://appchum.com/css/skeleton.css">
  <link rel="icon" type="image/ico" href="https://appchum.com/images/favicon.ico">
</head>
<body>
    <div class="container">
        <?php if($show_login){ echo '
        <div class="row">
            <div class="twelve columns">
                <center>
                    <p>You only have one atempt. If you failed, you will be blocked for a while.</p>
                    <form action="" method="POST">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email"/>
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" /> <br />
                        <input type="submit" name="login" value="Login" class="button-primary" />                                
                    </form>
                </center>
            </div>
        </div>';}
        ?>
        <div class="row">
            <div class="twelve columns">
                <center>
                    <?php if($show_dash){ 
                    echo '<h4>Available databases</h4>';
                    echo $db_list;
                    }
                    ?>
                </center>
            </div>
        </div>
        <div class="row">
            <div class="twelve columns">
                <center>
                    <?php 
                    if($show_db){echo '<h5>'.$_GET["db"].'</h5>';}
                    ?>
                    <table>
                        <thead>
                            <?php
                            if($show_db){echo '
                            <tr>
                                <th>Key</th>
                                <th>Value</th>
                            </tr>';
                            }?>
                        </thead>
                        <tbody>
                            <?php  if($show_db){
                            echo $tb_out;
                            }
                            ?>
                        </tbody>
                </table>
                <?php if($show_dash){echo '
                <form action="" method="POST">
                    <input type="submit" name="logout" value="Logout" class="button-primary"/>
                </form>';}
                ?>
                </center>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="twelve columns">
                <center>
                    <a href="/">Home page</a> |
                    <a href="https://appchum.com/apps/app/feedback">Feedback</a> |
                    <a href="https://appchum.com/apps/app/join">Join</a> |
                    <a href="https://appchum.com/privacy.html">Privacy policy</a> |
                    <a href="https://appchum.com/terms.html">Terms and conditions</a> |
                    <a href="https://appchum.com/about.html">About</a>
                </center>
            </div>
        </div>
    </div>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156056435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156056435-1');
</script>
</body>
</html>
