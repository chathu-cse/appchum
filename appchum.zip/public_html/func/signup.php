<?php                

function validate_email($email){
    $re = '/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/'; 
    return preg_match($re,$email);
}

function validate_app($app){
    $re = '/^[a-zA-Z\d-]{1,8}$/';
    return preg_match($re,$app);
}

function validate_pass($pass){
    $n = strlen($pass);
    
    if($n<4){
        return false;
    }else{
        return true;
    }
}

function email_exists($email){
    global $conn;
    $hd = array("id");
    $wh["email"] =strtolower($email);
    $query = select_table("apps",$hd,$wh);
    $result = mysqli_query($conn,$query);
    $num = mysqli_num_rows($result);
    
    if($num == 1){
        return true;
    }else{
        return false;
    }
}

function app_exists($email){
    global $conn;
    $hd = array("id");
    $wh["app_name"] =strtolower($email);
    $query = select_table("apps",$hd,$wh);
    $result = mysqli_query($conn,$query);
    $num = mysqli_num_rows($result);
    
    if($num == 1){
        return true;
    }else{
        return false;
    }
}

function signup($email,$app,$pass){
    global $conn;
    $opt["cost"] = 4;
    $hash = password_hash($pass,PASSWORD_BCRYPT,$opt);
    $appid = rand(10000,10000000);
    
    $st["app_id"] = $appid;
    $st["app_name"] =strtolower($app);
    $st["email"] =strtolower($email);
    $st["password"] = $hash;
    
    //cookie data
    $exp = time() + 86400 * 60;
    
    //session
    ini_set( 'session.cookie_httponly', 1 );
    session_start();
    
    $query = insert_table("apps",$st);
    if(mysqli_query($conn,$query)){
        setcookie("token",$appid,$exp,"/",NULL,false,true);
        $_SESSION["appname"]= $app;
        
        echo "1";
    }else{
        echo "Unexpected error occured.";
    }
    
}

if(!isset($_POST["d"])){
    die("Something went wrong.");
}

$obj = json_decode($_POST["d"],true);

if(isset($obj["appname"]) && isset($obj["password"]) && isset($obj["email"])){
    include("../engine/dbs/mysql.php");
    include("../engine/dbs/mysql_funs.php");
    
    $app = $obj["appname"];
    $pass = $obj["password"];
    $ema = $obj["email"];
    
    if(validate_pass($pass) && validate_email($ema) && validate_app($app)){
        if(!app_exists($app)){
            if(!email_exists($ema)){
                signup($ema,$app,$pass);
            }else{
                echo "Email already exists. Try appchum.com/ide to edit previous app.";
            }
        }else{
            echo "App already exists. Try different name.";
        }
    }else{
        echo "Something went wrong. Try again later.";
    }
    
}else{
    die("<h1>Access denied.");
}

?>