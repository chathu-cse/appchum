<?php
include("../engine/dbs/mysql.php");
include("../engine/dbs/mysql_funs.php");

$page = 1;

if(isset($_GET["page"])){
    $rawpage = $_GET["page"];
    if(preg_match("/^\d+$/",$rawpage)){
        $page = $rawpage;
    }elseif(preg_match("/^(\d+)\?./",$rawpage)){
        preg_match("/^(\d+)\?./",$rawpage,$mat);
        $page = $mat[1];
    }else{
        $page = 1;
    }
}

$offset = ($page * 10) - 10;
                                                                                                                                                       
$query = "SELECT `title`,`date`,`by`,`short`,`hash` FROM `posts` ORDER BY `id` DESC LIMIT 10 OFFSET ".$offset;
$result = mysqli_query($conn,$query);

$temp = '
<h4><a href="{{link}}">{{title}}</a></h4>
<h6>on {{date}} | by {{by}}</h6>
<p>{{short}}</p>
<hr />
';
$bef = array("{{link}}","{{title}}","{{date}}","{{by}}","{{short}}");

$output = "";
$back = "";
$next = "";

if(mysqli_num_rows($result) == 0){
    $output = "<h2>No more posts. :(</h2>";
}else{
    
    if(mysqli_num_rows($result) == 10){
        $next = ' href="'.($page+1).'" ';
    }
    
    if($page != 1){
        $back = ' href="'.($page-1).'" ';
    }
    
    while($row = mysqli_fetch_assoc($result)){
        $lnk = "https://appchum.com/blog/post/".$row["hash"];
        
        $aff = array($lnk,reval($row["title"]),reval($row["date"]),reval($row["by"]),reval($row["short"]));
        $segm = str_replace($bef,$aff,$temp);
        $output .= $segm;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <title>Blog - Appchum</title>
  <meta name="description" content="Tutorials and News from Appchum">
  <meta name="author" content="Dumindu Chathuranga">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://appchum.com/css/skeleton.css">
  <link rel="icon" type="image/ico" href="https://appchum.com/images/favicon.ico">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="twelve columns">
                <h6>Back to <a href="../">Appchum</a></h6>
                <?php echo $output; ?>
                <center>
                    <a <?php echo $back; ?>>&lt; back</a> | <a <?php echo $next; ?>>next &gt;</a>
                </center>
            </div>
        </div>
        <hr />
        <div class="row">
            <div class="twelve columns">
                <center>
                    <a href="/">Home page</a> |
                    <a href="https://appchum.com/apps/app/feedback">Feedback</a> |
                    <a href="https://appchum.com/apps/app/join">Join</a> |
                    <a href="https://appchum.com/privacy.html">Privacy policy</a> |
                    <a href="https://appchum.com/terms.html">Terms and conditions</a> |
                    <a href="https://appchum.com/about.html">About</a>
                </center>
            </div>
        </div>
    </div>
    <script src="https://appchum.com/js/highlight.pack.js"></script>
    <script>hljs.initHighlightingOnLoad();</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156056435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156056435-1');
</script>
</body>
</html>
